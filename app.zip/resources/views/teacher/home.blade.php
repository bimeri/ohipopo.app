@include('layouts.teacher')
@section('title')
    Teacher Home
@endsection
@section('content')
  <h1>Teacher home</h1>
@endsection
