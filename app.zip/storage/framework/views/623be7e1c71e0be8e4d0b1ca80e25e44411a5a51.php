<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('style'); ?>
<style>
    td, th, tr{
        border-collapse: collapse;
        border: 1px solid black !important;
        font-size: 14px !important;
        text-align: center !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col s12 m10 offset-m1 w3-border w3-padding radius white w3-border-amber">
        <h5 class="center">Adding video to: <b><?php echo e($subject->name); ?></b> under the  topic: <b><?php echo e($topicName->topic->topicName); ?></b></h5>
        <br>
        <div class="row">
            <form action="<?php echo e(route('video.add_one')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="topicId" value="<?php echo e($topicName->topic_id); ?>">
                <div class="input-field col s12 m2 offset-m2">
                    <label for="vname">Video name</label>
                    <input type="text" name="vname" class="validate" />
                </div>
                <div class="input-field col s12 m5">
                    <label for="url">Video link (URL)</label>
                    <input type="url" name="vlink" class="validate" />
                </div>
                <div class="input-field col s12 m3">
                    <button class="btn orange white-text waves-effect waves-light">Save</button>
                </div>
            </form>
        </div>
        <div class="col s12 m12 w3-padding" style="overflow-x:auto !important;">
            <table class="w3-table w3-striped w3-border-blue" style="font-size: 15px !important;">
                <tr class="w3-orange">
                    <th>S/N</th>
                    <th>Topic Name</th>
                    <th>video name</th>
                    <th>video link (URL)</th>
                    <th colspan="2">Action</th>
                </tr>
                <tbody>
                    <?php $__currentLoopData = $topicvideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $topicvideo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($topicvideo->topic->topicName); ?></td>
                            <td><?php echo e($topicvideo->videoName); ?></td>
                            <td><?php echo e($topicvideo->video_url); ?></td>
                            <td><button type="button" href="#modal<?php echo e($key + 1); ?>" class="modal-trigger w3-btn orange orange-text lighten-4">Edit <i class="fa fa-pen"></i></button></td>
                            <td>
                                <form action="<?php echo e(route('video.delete.method')); ?>" method="post" id="form<?php echo e($topicvideo->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="videoId" value="<?php echo e($topicvideo->id); ?>">
                                    <button type="button" class="w3-btn red red-text lighten-4" onclick="deletes<?php echo e($topicvideo->id); ?>()" id="btn-submit<?php echo e($topicvideo->id); ?>">Delete <i class="fa fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        
                        <?php echo $__env->make('includes.admin.edit_video', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<a href="<?php echo e(route('admin.addVideos')); ?>" class="btn blue blue-text lighten-4 waves-effect waves-light" style="position: fixed; botton:10px; left: 10px"><i class="fa fa-arrow-alt-circle-left"></i> go back</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ohipopo\resources\views/admin/videos/addOnevideo.blade.php ENDPATH**/ ?>