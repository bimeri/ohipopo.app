<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo e(__('Ohipopo.org')); ?></title>
        <!-- Fonts -->
        <link rel="icon" href="<?php echo e(URL::asset('/asset/logo/newLogo.png')); ?>" type="image/x-icon">
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <link rel="stylesheet" href="<?php echo e(URL::asset('materialize/css/materialize.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('fontawesome/css/all.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('mycss.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('w3.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(URL::asset('toaster.css')); ?>" />
        <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    </head>
    <body>
            <div class="cont col s12 m4 offset-m4" style="border-radius: 10px !important">
                <div class="moda">
                    <form method="get" action="<?php echo e(route('user.login')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="card-action orange lighten-1 white-text" style="height: 150px">
                            <center>
                                <img src="<?php echo e(URL::asset('asset/logo/newLogo.png')); ?>" class="w3-center" alt="logo" height="140" width="200">
                            </center>
                            <h6 class="center" style="margin-top: -20px">Enter your credentials to login</h6>
                        </div>
                        <?php if(count($errors) > 0): ?>
                        <center>
                            <div class="w3-container red-text w3-card-8 w3-margin-top materialize-red lighten-4" style="display: block; position: relative; z-index: 30">
                                <span onclick="this.parentElement.style.display='none'" class="close right w3-padding-16 w3-margin-top" style="cursor: pointer">x</span>
                                <ul id="error" class="w3-margin w3-padding">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li style="text-align: center;"><?php echo e($error); ?> </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <center><i class="mdi-action-thumb-down" style="font-size: 25px;"></i></center>
                                </ul>
                            </div>
                        </center>
                        <?php endif; ?>

                        <div class="card-content w3-padding">
                            <div class="form-field input-field">
                                <i class="fa fa-pen prefix small orange-text"></i>
                                <input type="text" name="user_name" class="validate" id="username" value="<?php echo e(old('user_name')); ?>">
                                <label for="username">Enter your user name</label>
                            </div>
                            <div class="form-field input-field">
                                <i class="fa fa-lock prefix small orange-text"></i>
                                <input type="password" name="password" class="validate" id="password" value="">
                                <label for="password">Password</label>
                            </div><br>
                            <div class="form-field">
                                <p class="left">
                                    <label>
                                    <input type="checkbox" name="remember" id="remember" value="<?php echo e(old('rememberMe')); ?>"/>
                                    <span>Remember me</span>
                                    <label style="color: transparent">dvbrstvf rgbwsr gtghber hte therg ergsr h3egerg h</label>
                                    </label>
                                </p>
                                <p class="right">
                                    <label class="w3-large"><a class="teal-text w3-medium">forgot password</a>&nbsp;&nbsp; <i class="fa fa-unlock-alt"></i></label>
                                </p>
                            </div><br>
                        </div>
                            <div class="form-field">
                                <button class="btn orange waves-effect waves-blues" onclick="load()" style="width: 100%">Login</button>
                            </div>
                        </div>
                    </form>
              </div>

            <div id="menu" class="orange" style="height: 800px !important; width: 100% !important; position: fixed !important; top:0px; bottom: 0px; left: 0px; right: 0px; z-index: 1000; opacity:0.5 !important">
                <div class="w3-margin-top">
                    <center>
                        <div class="preloader-wrapper big active spinner-white" style="margin-top: 220px !important;">
                            <div class="spinner-layer spinner-white-only">
                                <div class="circle-clipper left">
                                    <div class="circle"></div>
                                </div>
                                <div class="gap-patch">
                                    <div class="circle"></div>
                                </div>
                                <div class="circle-clipper right">
                                    <div class="circle"></div>
                                </div>
                            </div>
                        </div>
                    </center>
                </div>
            </div>

        <div class="footer_one">
            <center>
                <p id="dateField" style="color: white;">&nbsp;</p>
                <p style="text-align: center; color: #fff">&copy;Powered by
                    <a  target="_blank" href ="#" style="color:#00ccff"> Bimeri. Ltd</a>
                </p>
            </center>
        </div>
         <script src="<?php echo e(URL::asset('toaster.js')); ?>"></script>
         <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="<?php echo e(URL::asset('materialize/js/materialize.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('myjs.js')); ?>"></script>

    <script>
        <?php if(Session::has('message')): ?>
          var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
          toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": true,
                "progressBar": false,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "7000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
                }
          switch(type){
              case 'info':
                  toastr.info("<?php echo e(Session::get('message')); ?>");
                  break;

              case 'warning':
                  toastr.warning("<?php echo e(Session::get('message')); ?>");
                  break;

              case 'success':
                  Command: toastr["success"]("<?php echo e(Session::get('message')); ?>")
                  break;

              case 'error':
                  toastr.error("<?php echo e(Session::get('message')); ?>");
                  break;
          }
        <?php endif; ?>
      </script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\ohipopo\resources\views/auth/login.blade.php ENDPATH**/ ?>