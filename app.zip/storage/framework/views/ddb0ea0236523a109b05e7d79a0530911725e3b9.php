<script>
    function deletes<?php echo e($subject->id); ?>(){
  $(document).on('click', '#btn-submit<?php echo e($subject->id); ?>', function(e) {
      e.preventDefault();
     swal({
            title: "Are you sure you want to delete?",
            text: "be careful because students may have registered the subject already!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
  }).then(function (willUpdate) {
    if (willUpdate) {
      swal("Poof! The subject has been deleted successfully", {
        icon: "success",
      });
      $('#form<?php echo e($subject->id); ?>').submit();
    } else {
      swal("the subject remain unchanged!");
    }
      });
  });
  }
</script>

<div id="modal<?php echo e($key + 1); ?>" class="modal modal-fixed-footer">
    <div class="modal-content">
      <h4 class="w3-center orange-text">Edit The subjects</h4>
      <hr style="border-top: 1px solid orange">
        <div class="row">
            <form action="<?php echo e(route('subject.edit.method')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e($subject->id); ?>" name="subjectId" />
                <div class="row">
                    <div class="input-field col 12 m3">
                        <label for="name">Subject name</label>
                        <input type="text" value="<?php echo e($subject->name); ?>" name="subject" class="autocompleteSubject validate" id="name" required/>
                    </div>
                    <div class="col 12 m3">
                        <select name="level" class="browser-default" required>
                            <option value="<?php echo e($subject->level_id); ?>" selected><?php echo e($subject->level->levelName); ?></option>
                            <?php $__currentLoopData = App\Models\Level::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($level->id); ?>"><?php echo e($level->levelName); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="input-field col 12 m3">
                        <label for="teacher">teacher's name</label>
                        <input type="text" value="<?php echo e($subject->author); ?>" name="teacher" id="teacher" class="validate" required/>
                    </div>
                    <div class="input-field col 12 m3">
                        <label for="topic">Number of topic</label>
                        <input type="number" value="<?php echo e($subject->topic); ?>" name="topic" id="topic" class="validate" required/>
                    </div>
                </div>
                <div class="row">
                    <div class="file-field input-field col s12 m4">
                        <div class="file-path-wrapper">
                          <input class="file-path validate" name="profile_image" type="text" value="<?php echo e($subject->logo); ?>" placeholder="upload subject logo">
                        </div>
                    </div>
                    <div class="input-field col s12 m7">
                        <label for="logo">Default URL</label>
                        <input type="url" name="url" class="validate" value="<?php echo e($subject->url); ?>" />
                    </div>
                </div>
                <div class="row">
                    <div class="col s12 m4 offset-m3">
                        <button type="submit" class="btn orange white-text waves-light waves-effect col s12 m4 offset-m3" style="width 100%">Update subjects</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="modal-close red waves-effect waves-green btn-flat right white-text">Cancel</button>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ohipopo\resources\views/includes/admin/edit_subject.blade.php ENDPATH**/ ?>