<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('style'); ?>
<style>
    td, th, tr{
        border-collapse: collapse;
        border: 1px solid black !important;
        font-size: 14px !important;
        text-align: center !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col s12 m10 offset-m1 w3-border w3-padding radius white w3-border-amber">
        <h5 class="center">Select the topic you wish to add video</h5><hr>
        <div id="message"></div>
        <form action="<?php echo e(route('add.one.video')); ?>" method="get">
            <?php echo csrf_field(); ?>
            <div class="col s12 m3">
                <select class="browser-default" id="level" onchange="getSubjects()">
                    <option value="">select the class</option>
                    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($level->id); ?>"><?php echo e($level->levelName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col s12 m3">
                <select class="browser-default" name="subjectId" id="subj" required onchange="selectTopics()">
                    <option value="">select the subjects</option>
                </select>
            </div>
            <div class="col s12 m3">
                <select class="browser-default" name="topicId" id="topics" required>
                    <option value="">select the topic</option>
                </select>
            </div>
            <div class="col s12 m3">
                <button class="w3-btn waves-light waves-effect orange white-text">Submit</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ohipopo\resources\views/admin/videos/videos.blade.php ENDPATH**/ ?>