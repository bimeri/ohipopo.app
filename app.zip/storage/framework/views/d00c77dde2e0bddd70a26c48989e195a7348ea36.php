<?php $__env->startSection('title', 'Add Subject'); ?>
<?php $__env->startSection('style'); ?>
<style>
    td, th, tr{
        border-collapse: collapse;
        border: 1px solid black !important;
        font-size: 14px !important;
        text-align: center !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col s12 m10 offset-m1 w3-border w3-padding radius white w3-border-amber">
        <h5 class="center">Add Subject</h5>
        <form action="<?php echo e(route('subject.add.method')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="input-field col 12 m3">
                    <label for="name">Enter Subject name</label>
                    <input type="text" value="" name="subject" class="autocompleteSubject validate" id="name" required/>
                </div>
                <div class="input-field col 12 m3">
                    <select name="level_id" required>
                        <option value="">select the level or Class</option>
                        <?php $__currentLoopData = App\Models\Level::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($level->id); ?>"><?php echo e($level->levelName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="input-field col 12 m3">
                    <label for="teacher">Enter teacher's name</label>
                    <input type="text" value="" name="teacher" id="teacher" class="validate" required/>

                </div>
                <div class="input-field col 12 m3">
                    <label for="topic">Enter number of topic</label>
                    <input type="number" placeholder="example 10" name="topic" id="topic" class="validate" required/>
                </div>
            </div>
            <div class="row">
                <div class="file-field input-field col s12 m3 offset-m2">
                    <div class="btn">
                      <input type="file" name="profile_image" id="imgInp">
                    </div>
                    <div class="file-path-wrapper">
                        <img id="blah" src="#" alt="Upload logo" height="60" width="70"/>
                      <input class="file-path validate" name="profile_image" type="text" placeholder="upload subject logo">
                    </div>
                </div>

                <div class="input-field col s12 m4">
                    <label for="logo">enter default URL</label>
                    <input type="url" name="url" class="validate" />
                </div>
            </div>
            <div class="row">
                <div class="col s12 m4 offset-m3">
                    <button type="submit" class="btn orange white-text waves-light waves-effect col s12 m4 offset-m3" style="width 100%">Save subjects</button>
                </div>
            </div>
        </form>
        <hr>
        <div class="row">
            <div class="col s12 m12 w3-padding" style="overflow-x:auto !important;">
                <h5 class="center">Result showing latest 7 registered subjects</h5>
                <table class="w3-table w3-striped w3-border-blue" style="font-size: 15px !important;">
                    <tr class="w3-orange">
                        <th>S/N</th>
                        <th>Subject Name</th>
                        <th>Subject Author</th>
                        <th>Topics</th>
                        <th>Level</th>
                        <th>Icon</th>
                        <th>Default video</th>
                    </tr>
                    <tbody>
                        <?php $__currentLoopData = App\Models\Subject::getTenSubject(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($subject->name); ?></td>
                                <td><?php echo e($subject->author); ?></td>
                                <td><?php echo e($subject->topic); ?></td>
                                <td><?php echo e($subject->level->levelName); ?></td>
                                <td><img src="<?php echo e(URL::asset(''.$subject->logo.'')); ?>" height="50" width="70"></td>
                                <td> <video src="<?php echo e($subject->url); ?>" height="50" width="70"></video> </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ohipopo\resources\views/admin/addSubject.blade.php ENDPATH**/ ?>