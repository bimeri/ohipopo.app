<div class="row">
    <div class="col s10 offset-s1 m6 offset-m3">
        <?php if(count($errors) > 0): ?>
        <center>
            <div class="w3-container red-text w3-card-8 w3-margin-top materialize-red lighten-4" style="display: block; position: relative; z-index: 30">
                <span onclick="this.parentElement.style.display='none'" class="close right w3-padding-16 w3-margin-top" style="cursor: pointer">x</span>
                <ul id="error" class="w3-margin w3-padding">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="text-align: center;"><?php echo e($error); ?> </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <center><i class="mdi-action-thumb-down" style="font-size: 25px;"></i></center>
                </ul>
            </div>
        </center>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ohipopo\resources\views/error.blade.php ENDPATH**/ ?>